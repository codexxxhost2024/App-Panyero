"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { cashIn } from "@/app/actions/wallet"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CreditCard, Building2, Wallet, QrCode, ArrowRight, Smartphone } from 'lucide-react'
import { toast } from "sonner"

const cashInMethods = [
  { 
    id: "bank",
    icon: Building2,
    title: "Bank Transfer",
    description: "Transfer from your bank account"
  },
  {
    id: "card",
    icon: CreditCard,
    title: "Debit/Credit Card",
    description: "Add money using your card"
  },
  {
    id: "ewallet",
    icon: Wallet,
    title: "E-Wallet",
    description: "Transfer from another e-wallet"
  },
  {
    id: "qr",
    icon: QrCode,
    title: "QR Code",
    description: "Scan to add money"
  },
  {
    id: "gcash",
    icon: Smartphone,
    title: "GCash",
    description: "Send to 09211514034"
  }
]

export default function CashInPage() {
  const { user } = useAuth()
  const [selectedMethod, setSelectedMethod] = useState("")
  const [amount, setAmount] = useState("")
  const [loading, setLoading] = useState(false)

  const handleCashIn = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !selectedMethod) return

    try {
      setLoading(true)
      const result = await cashIn(
        user.id,
        user.id,
        Number(amount),
        selectedMethod
      )

      if (result.success) {
        toast.success("Cash in successful")
        setAmount("")
        setSelectedMethod("")
      } else {
        toast.error(result.error || "Failed to cash in")
      }
    } catch (error) {
      console.error("Error cashing in:", error)
      toast.error("Failed to cash in")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6">Cash In</h1>

        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Quick Cash In</h2>
          <div className="grid grid-cols-3 gap-2">
            {[100, 500, 1000, 2000, 5000, 10000].map((amount) => (
              <Button
                key={amount}
                variant="outline"
                onClick={() => setAmount(amount.toString())}
              >
                ₱{amount}
              </Button>
            ))}
          </div>
        </div>

        <form onSubmit={handleCashIn} className="space-y-6">
          <div>
            <Label htmlFor="amount">Amount (PHP)</Label>
            <Input
              id="amount"
              type="number"
              min="1"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>

          <div className="space-y-4">
            <Label>Select Payment Method</Label>
            {cashInMethods.map((method) => (
              <div
                key={method.id}
                className={`flex items-center gap-4 rounded-lg border p-4 cursor-pointer ${
                  selectedMethod === method.id ? "border-blue-500 bg-blue-50" : ""
                }`}
                onClick={() => setSelectedMethod(method.id)}
              >
                <div className="rounded-full bg-gray-100 p-3">
                  <method.icon className="h-6 w-6 text-gray-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">{method.title}</h3>
                  <p className="text-sm text-gray-600">{method.description}</p>
                </div>
                <ArrowRight className="h-5 w-5 text-gray-400" />
              </div>
            ))}
          </div>

          <Button
            type="submit"
            className="w-full"
            disabled={loading || !selectedMethod}
          >
            {loading ? "Processing..." : "Continue"}
          </Button>
        </form>
      </div>

      <BottomNav />
    </main>
  )
}

