import { OnboardingSlider } from '@/components/onboarding-slider'

export default function OnboardingPage() {
  return <OnboardingSlider />
}

