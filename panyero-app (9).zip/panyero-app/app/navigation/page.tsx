import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Compass, Anchor, Map, Wind, Navigation2 } from 'lucide-react'
import { Button } from "@/components/ui/button"

const navigationTools = [
  {
    icon: Compass,
    title: "Digital Compass",
    description: "Real-time magnetic heading",
  },
  {
    icon: Map,
    title: "Route Planning",
    description: "Plan and optimize your routes",
  },
  {
    icon: Wind,
    title: "Weather Updates",
    description: "Marine weather forecasts",
  },
  {
    icon: Navigation2,
    title: "GPS Navigation",
    description: "Precise positioning system",
  },
]

export default function NavigationPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="space-y-6 p-4">
        <h1 className="text-2xl font-bold">Navigation Tools</h1>
        
        <div className="grid gap-4">
          {navigationTools.map((tool, index) => (
            <div key={index} className="rounded-lg bg-white p-4 shadow-sm">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-blue-100 p-3">
                  <tool.icon className="h-6 w-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h2 className="font-semibold">{tool.title}</h2>
                  <p className="text-sm text-gray-600">{tool.description}</p>
                </div>
              </div>
              <Button className="mt-4 w-full">Open Tool</Button>
            </div>
          ))}
        </div>

        <div className="rounded-lg bg-blue-50 p-4">
          <div className="flex items-center gap-4">
            <Anchor className="h-6 w-6 text-blue-600" />
            <div>
              <h3 className="font-semibold">Current Position</h3>
              <p className="text-sm text-gray-600">Lat: 14.5995° N, Long: 120.9842° E</p>
            </div>
          </div>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

