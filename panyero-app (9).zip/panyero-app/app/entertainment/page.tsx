"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dice1Icon as Dice, WalletCardsIcon as Cards, Coins, Gift, Clover } from 'lucide-react'
import { toast } from "sonner"

const lotteryGames = [
  { name: "6/49 Lotto", jackpot: "₱50,000,000", drawTime: "9:00 PM" },
  { name: "6/58 Ultra Lotto", jackpot: "₱100,000,000", drawTime: "9:00 PM" },
  { name: "6/42 Lotto", jackpot: "₱25,000,000", drawTime: "9:00 PM" },
  { name: "6/55 Grand Lotto", jackpot: "₱75,000,000", drawTime: "9:00 PM" },
]

const casinoGames = [
  { name: "Slots", icon: Coins, players: "1,234" },
  { name: "Blackjack", icon: Cards, players: "567" },
  { name: "Roulette", icon: Gift, players: "789" },
  { name: "Poker", icon: Cards, players: "901" },
]

export default function EntertainmentPage() {
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([])
  const [betAmount, setBetAmount] = useState("")

  const handleNumberSelect = (number: number) => {
    if (selectedNumbers.includes(number)) {
      setSelectedNumbers(selectedNumbers.filter(n => n !== number))
    } else if (selectedNumbers.length < 6) {
      setSelectedNumbers([...selectedNumbers, number])
    }
  }

  const handleLotterySubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedNumbers.length !== 6) {
      toast.error("Please select 6 numbers")
      return
    }
    toast.success(`Lottery ticket purchased with numbers: ${selectedNumbers.join(", ")}`)
    setSelectedNumbers([])
  }

  const handleCasinoBet = (game: string) => {
    if (!betAmount) {
      toast.error("Please enter a bet amount")
      return
    }
    toast.success(`Bet placed on ${game} for ₱${betAmount}`)
    setBetAmount("")
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Entertainment</h1>

        <Tabs defaultValue="lottery">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="lottery">Lottery</TabsTrigger>
            <TabsTrigger value="casino">Casino</TabsTrigger>
          </TabsList>
          <TabsContent value="lottery">
            <div className="space-y-4">
              {lotteryGames.map((game, index) => (
                <div key={index} className="bg-white rounded-lg p-4 shadow-sm">
                  <h2 className="text-lg font-semibold mb-2">{game.name}</h2>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-500">Jackpot:</span>
                    <span className="text-green-600 font-bold">{game.jackpot}</span>
                  </div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm text-gray-500">Draw Time:</span>
                    <span>{game.drawTime}</span>
                  </div>
                  <Button className="w-full" onClick={() => toast.info(`Selected ${game.name}`)}>Place Bet</Button>
                </div>
              ))}
              <form onSubmit={handleLotterySubmit} className="bg-white rounded-lg p-4 shadow-sm">
                <h3 className="text-lg font-semibold mb-4">Select Your Numbers</h3>
                <div className="grid grid-cols-7 gap-2 mb-4">
                  {Array.from({ length: 49 }, (_, i) => i + 1).map(number => (
                    <Button
                      key={number}
                      type="button"
                      variant={selectedNumbers.includes(number) ? "default" : "outline"}
                      className="w-10 h-10 p-0"
                      onClick={() => handleNumberSelect(number)}
                    >
                      {number}
                    </Button>
                  ))}
                </div>
                <Button type="submit" className="w-full">Submit Lottery Ticket</Button>
              </form>
            </div>
          </TabsContent>
          <TabsContent value="casino">
            <div className="space-y-4">
              {casinoGames.map((game, index) => (
                <div key={index} className="bg-white rounded-lg p-4 shadow-sm">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <game.icon className="h-8 w-8 text-purple-600 mr-3" />
                      <div>
                        <h2 className="text-lg font-semibold">{game.name}</h2>
                        <p className="text-sm text-gray-500">{game.players} players online</p>
                      </div>
                    </div>
                    <Button variant="outline" onClick={() => toast.info(`Opened ${game.name}`)}>Play Now</Button>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      placeholder="Bet amount"
                      value={betAmount}
                      onChange={(e) => setBetAmount(e.target.value)}
                      className="flex-grow"
                    />
                    <Button onClick={() => handleCasinoBet(game.name)}>Place Bet</Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <div className="bg-yellow-50 rounded-lg p-4 mt-6">
          <h2 className="text-lg font-semibold mb-2">Responsible Gaming</h2>
          <p className="text-sm text-gray-600">
            Please gamble responsibly. Set limits on your deposits, losses, and playing time. 
            If you need help, contact our support team for assistance.
          </p>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

