import { GamesList } from "@/components/games-list"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"

export default function GamesPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      <div className="p-4">
        <GamesList />
      </div>
      <BottomNav />
    </main>
  )
}

