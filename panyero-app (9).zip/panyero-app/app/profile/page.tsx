import { ProgressCircle } from "@/components/ui/progress-circle"

export default function Profile() {
  return (
    <div className="p-4">
      {/* rest of the code here */}
      <div className="mt-6 mb-4">
        <h2 className="text-lg font-semibold mb-2">Profile Completion</h2>
        <div className="flex items-center justify-between bg-white p-4 rounded-lg shadow-sm">
          <div>
            <p className="font-medium">Complete your profile</p>
            <p className="text-sm text-gray-600">Unlock all features</p>
          </div>
          <ProgressCircle value={70} size={60} strokeWidth={5} />
        </div>
      </div>
      {/* rest of the code here */}
    </div>
  )
}

