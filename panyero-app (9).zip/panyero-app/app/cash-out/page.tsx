"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { cashOut } from "@/app/actions/wallet"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Building2, CreditCard, Wallet, ArrowRight } from 'lucide-react'
import { toast } from "sonner"

const cashOutMethods = [
  {
    id: "bank",
    icon: Building2,
    title: "Bank Account",
    description: "Withdraw to your bank account"
  },
  {
    id: "card",
    icon: CreditCard,
    title: "Debit Card",
    description: "Instant withdrawal to card"
  },
  {
    id: "ewallet",
    icon: Wallet,
    title: "E-Wallet",
    description: "Transfer to another e-wallet"
  }
]

export default function CashOutPage() {
  const { user } = useAuth()
  const [selectedMethod, setSelectedMethod] = useState("")
  const [amount, setAmount] = useState("")
  const [loading, setLoading] = useState(false)

  const handleCashOut = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !selectedMethod) return

    try {
      setLoading(true)
      const result = await cashOut(
        user.id,
        user.id,
        Number(amount),
        selectedMethod
      )

      if (result.success) {
        toast.success("Cash out successful")
        setAmount("")
        setSelectedMethod("")
      } else {
        toast.error(result.error || "Failed to cash out")
      }
    } catch (error) {
      console.error("Error cashing out:", error)
      toast.error("Failed to cash out")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6">Cash Out</h1>

        <form onSubmit={handleCashOut} className="space-y-6">
          <div>
            <Label htmlFor="amount">Amount (PHP)</Label>
            <Input
              id="amount"
              type="number"
              min="1"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>

          <div className="space-y-4">
            <Label>Select Withdrawal Method</Label>
            {cashOutMethods.map((method) => (
              <div
                key={method.id}
                className={`flex items-center gap-4 rounded-lg border p-4 cursor-pointer ${
                  selectedMethod === method.id ? "border-blue-500 bg-blue-50" : ""
                }`}
                onClick={() => setSelectedMethod(method.id)}
              >
                <div className="rounded-full bg-gray-100 p-3">
                  <method.icon className="h-6 w-6 text-gray-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">{method.title}</h3>
                  <p className="text-sm text-gray-600">{method.description}</p>
                </div>
                <ArrowRight className="h-5 w-5 text-gray-400" />
              </div>
            ))}
          </div>

          <Button
            type="submit"
            className="w-full"
            disabled={loading || !selectedMethod}
          >
            {loading ? "Processing..." : "Continue"}
          </Button>
        </form>
      </div>

      <BottomNav />
    </main>
  )
}

