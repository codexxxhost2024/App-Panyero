import { Navigation } from "@/components/navigation"
import { VoiceAssistant } from "@/components/voice-assistant"

export default function FlightsPage() {
  return (
    <main className="min-h-screen bg-purple-50 pb-20">
      <div className="bg-purple-600 p-6 text-white">
        <h1 className="text-2xl font-bold">Flight Booking</h1>
      </div>
      <div className="p-4">
        <form className="space-y-4">
          <div>
            <label htmlFor="from" className="block text-sm font-medium text-gray-700">From</label>
            <input type="text" id="from" name="from" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500" />
          </div>
          <div>
            <label htmlFor="to" className="block text-sm font-medium text-gray-700">To</label>
            <input type="text" id="to" name="to" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500" />
          </div>
          <div>
            <label htmlFor="date" className="block text-sm font-medium text-gray-700">Date</label>
            <input type="date" id="date" name="date" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500" />
          </div>
          <button type="submit" className="w-full rounded-md bg-purple-600 px-4 py-2 text-white hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2">
            Search Flights
          </button>
        </form>
      </div>
      <Navigation />
      <VoiceAssistant />
    </main>
  )
}

