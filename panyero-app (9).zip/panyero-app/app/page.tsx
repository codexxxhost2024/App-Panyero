import { BottomNav } from "@/components/ui/bottom-nav"
import { AnimatedWelcome } from '@/components/animated-welcome'
import { AuthButtons } from '@/components/auth-buttons'
import { AnimatedBanners } from '@/components/animated-banners'

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <div className="w-full h-full flex flex-col justify-between bg-gray-100 px-6 py-12">
        <AnimatedWelcome />
        <AnimatedBanners title="Panyero" />
        <AuthButtons />
      </div>
      <BottomNav />
    </main>
  )
}

