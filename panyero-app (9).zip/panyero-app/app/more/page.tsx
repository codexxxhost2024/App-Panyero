import { Navigation } from "@/components/navigation"
import { VoiceAssistant } from "@/components/voice-assistant"
import { School, Film, Wallet } from 'lucide-react'
import { ServiceCard } from "@/components/service-card"

export default function MorePage() {
  return (
    <main className="min-h-screen bg-purple-50 pb-20">
      <div className="bg-purple-600 p-6 text-white">
        <h1 className="text-2xl font-bold">More Services</h1>
      </div>
      <div className="p-4">
        <div className="grid grid-cols-2 gap-4">
          <ServiceCard icon={School} title="Review Center" />
          <ServiceCard icon={Film} title="Entertainment" />
          <ServiceCard icon={Wallet} title="Lottery" />
        </div>
      </div>
      <Navigation />
      <VoiceAssistant />
    </main>
  )
}

