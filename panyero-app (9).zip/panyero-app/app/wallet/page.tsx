"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowDownLeft, ArrowUpRight, DollarSign, Filter } from 'lucide-react'
import { getWallet, getTransactions } from "@/lib/wallet-service"
import { type Transaction } from "@/lib/auth"
import Link from "next/link";

export default function WalletPage() {
  const { user } = useAuth()
  const [balance, setBalance] = useState(0)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchWalletData = async () => {
      if (user) {
        try {
          const wallet = await getWallet(user.id)
          setBalance(wallet?.balance || 0)
          const fetchedTransactions = await getTransactions(user.id)
          setTransactions(fetchedTransactions)
        } catch (error) {
          console.error("Error fetching wallet data:", error)
        } finally {
          setLoading(false)
        }
      }
    }
    fetchWalletData()
  }, [user])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' })
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Wallet</h1>

        <Card>
          <CardHeader>
            <CardTitle>Available Balance</CardTitle>
            <CardDescription>Your current wallet balance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{formatCurrency(balance)}</div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button asChild variant="outline" className="flex-1 mr-2">
              <Link href="/cash-in">
                <ArrowDownLeft className="mr-2 h-4 w-4" /> Cash In
              </Link>
            </Button>
            <Button asChild variant="outline" className="flex-1 ml-2">
              <Link href="/cash-out">
                <ArrowUpRight className="mr-2 h-4 w-4" /> Cash Out
              </Link>
            </Button>
          </CardFooter>
        </Card>

        <div className="mt-6 mb-4">
          <h2 className="text-lg font-semibold mb-2">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-4">
            <Button asChild variant="outline">
              <Link href="/cash-in">
                <ArrowDownLeft className="mr-2 h-4 w-4" />
                Cash In
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/cash-out">
                <ArrowUpRight className="mr-2 h-4 w-4" />
                Cash Out
              </Link>
            </Button>
          </div>
        </div>

        <div className="mt-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Transaction History</h2>
            <Button variant="ghost" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>
          <Tabs defaultValue="all">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="incoming">Incoming</TabsTrigger>
              <TabsTrigger value="outgoing">Outgoing</TabsTrigger>
            </TabsList>
            <TabsContent value="all">
              <TransactionList transactions={transactions} />
            </TabsContent>
            <TabsContent value="incoming">
              <TransactionList transactions={transactions.filter(t => t.amount > 0)} />
            </TabsContent>
            <TabsContent value="outgoing">
              <TransactionList transactions={transactions.filter(t => t.amount < 0)} />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

function TransactionList({ transactions }: { transactions: Transaction[] }) {
  return (
    <div className="space-y-4">
      {transactions.map((transaction) => (
        <div key={transaction.id} className="bg-white rounded-lg p-4 shadow-sm flex items-center justify-between">
          <div className="flex items-center">
            {transaction.amount > 0 ? (
              <ArrowDownLeft className="h-8 w-8 text-green-500 mr-3" />
            ) : (
              <ArrowUpRight className="h-8 w-8 text-red-500 mr-3" />
            )}
            <div>
              <p className="font-medium">{transaction.description}</p>
              <p className="text-sm text-gray-500">{formatDate(transaction.created_at)}</p>
            </div>
          </div>
          <div className={`font-bold ${transaction.amount > 0 ? 'text-green-500' : 'text-red-500'}`}>
            {transaction.amount > 0 ? '+' : '-'} {formatCurrency(Math.abs(transaction.amount))}
          </div>
        </div>
      ))}
    </div>
  )
}

