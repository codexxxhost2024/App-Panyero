export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          created_at?: string
          updated_at?: string
        }
      }
      profiles: {
        Row: {
          id: string
          user_id: string
          full_name: string
          avatar_url: string | null
          seaman_book_no: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          user_id: string
          full_name: string
          avatar_url?: string | null
          seaman_book_no?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          full_name?: string
          avatar_url?: string | null
          seaman_book_no?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      wallets: {
        Row: {
          id: string
          user_id: string
          balance: number
          currency: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          user_id: string
          balance: number
          currency: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          balance?: number
          currency?: string
          created_at?: string
          updated_at?: string
        }
      }
      transactions: {
        Row: {
          id: string
          user_id: string
          type: string
          amount: number
          currency: string
          status: string
          description: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          user_id: string
          type: string
          amount: number
          currency: string
          status: string
          description: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          type?: string
          amount?: number
          currency?: string
          status?: string
          description?: string
          created_at?: string
          updated_at?: string
        }
      }
      lottery_tickets: {
        Row: {
          id: string
          user_id: string
          game_type: string
          numbers: number[]
          draw_date: string
          status: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          user_id: string
          game_type: string
          numbers: number[]
          draw_date: string
          status: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          game_type?: string
          numbers?: number[]
          draw_date?: string
          status?: string
          created_at?: string
          updated_at?: string
        }
      }
      casino_games: {
        Row: {
          id: string
          user_id: string
          game_type: string
          bet_amount: number
          win_amount: number | null
          status: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          user_id: string
          game_type: string
          bet_amount: number
          win_amount?: number | null
          status: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          game_type?: string
          bet_amount?: number
          win_amount?: number | null
          status?: string
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}

