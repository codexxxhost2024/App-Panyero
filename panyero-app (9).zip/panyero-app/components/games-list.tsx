"use client"

import { useState, useEffect } from 'react'
import { fetchGames, Game } from "@/lib/betting-service"
import { placeBet, getWallet } from "@/lib/wallet-service"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Clock, Trophy, Users, Wallet } from 'lucide-react'
import { toast } from "sonner"

export function GamesList() {
  const { user } = useAuth()
  const [games, setGames] = useState<Game[]>([])
  const [loading, setLoading] = useState(true)
  const [betAmounts, setBetAmounts] = useState<{ [key: string]: string }>({})
  const [userBalance, setUserBalance] = useState(0)

  useEffect(() => {
    const loadGames = async () => {
      const fetchedGames = await fetchGames()
      setGames(fetchedGames)
      setLoading(false)
    }
    loadGames()
  }, [])

  useEffect(() => {
    const loadBalance = async () => {
      if (user) {
        const wallet = await getWallet(user.id)
        setUserBalance(wallet?.balance || 0)
      }
    }
    loadBalance()
  }, [user])

  const handleBetAmountChange = (gameId: string, amount: string) => {
    setBetAmounts(prev => ({ ...prev, [gameId]: amount }))
  }

  const handlePlaceBet = async (game: Game) => {
    if (!user) {
      toast.error("Please sign in to place a bet")
      return
    }

    const betAmount = parseFloat(betAmounts[game.id] || "0")
    if (isNaN(betAmount) || betAmount <= 0) {
      toast.error("Please enter a valid bet amount")
      return
    }

    if (betAmount > userBalance) {
      toast.error("Insufficient balance")
      return
    }

    const result = await placeBet(user.id, game.id, betAmount)
    if (result.success) {
      toast.success(`Bet of ₱${betAmount} placed on ${game.name}`)
      setUserBalance(result.newBalance || 0)
      setBetAmounts(prev => ({ ...prev, [game.id]: "" }))
    } else {
      toast.error(result.error || "Failed to place bet")
    }
  }

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-gray-200 rounded w-3/4"></div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="h-4 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-5/6"></div>
              </div>
            </CardContent>
            <CardFooter>
              <div className="h-10 bg-gray-200 rounded w-full"></div>
            </CardFooter>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Available Games</h2>
        <div className="flex items-center gap-2">
          <Wallet className="h-5 w-5" />
          <span className="font-semibold">Balance: ₱{userBalance.toFixed(2)}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {games.map((game) => (
          <Card key={game.id}>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>{game.name}</span>
                <Badge variant="outline">{game.type}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{new Date(game.startTime).toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Trophy className="h-4 w-4" />
                    <span>Odds: {game.odds}</span>
                  </div>
                </div>
                {game.participants && (
                  <div className="flex items-center gap-1 text-sm">
                    <Users className="h-4 w-4" />
                    <span>{game.participants.join(" vs ")}</span>
                  </div>
                )}
                <div className="space-y-2">
                  <Label htmlFor={`bet-${game.id}`}>Place your bet</Label>
                  <div className="flex gap-2">
                    <Input
                      id={`bet-${game.id}`}
                      type="number"
                      min="1"
                      step="0.01"
                      placeholder="Enter amount"
                      value={betAmounts[game.id] || ""}
                      onChange={(e) => handleBetAmountChange(game.id, e.target.value)}
                    />
                    <Button 
                      onClick={() => handlePlaceBet(game)}
                      disabled={!betAmounts[game.id] || parseFloat(betAmounts[game.id]) <= 0}
                    >
                      Bet
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

