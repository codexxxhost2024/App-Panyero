"use client"

import { Anchor, Compass, Wallet, LifeBuoy, Menu } from 'lucide-react'
import Link from 'next/link'
import { cn } from '@/lib/utils'
import { usePathname } from 'next/navigation'

const navItems = [
  { icon: Wallet, label: "Wallet", href: "/wallet" },
  { icon: Compass, label: "Navigation", href: "/navigation" },
  { icon: Anchor, label: "Home", href: "/" },
  { icon: LifeBuoy, label: "Safety", href: "/safety" },
  { icon: Menu, label: "More", href: "/more" },
]

export function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t">
      <div className="flex items-center justify-around px-4 py-2">
        {navItems.map((item, index) => {
          const Icon = item.icon
          const isHome = item.label === "Home"
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center p-2 transition-all duration-200 ease-in-out",
                isHome ? "-mt-6" : "",
                pathname === item.href ? "text-blue-600" : "text-gray-600",
                "hover:text-blue-600 active:scale-90"
              )}
            >
              <div className={cn(
                "relative",
                isHome ? "p-4 bg-white rounded-full shadow-lg" : ""
              )}>
                <Icon className={cn(
                  "transition-transform duration-200 ease-in-out",
                  isHome ? "h-8 w-8" : "h-6 w-6",
                  "hover:scale-110"
                )} />
              </div>
              <span className={cn(
                "text-xs mt-1",
                isHome ? "sr-only" : ""
              )}>{item.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}

