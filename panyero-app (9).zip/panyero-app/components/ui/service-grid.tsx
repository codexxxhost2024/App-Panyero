import { cn } from "@/lib/utils"
import { TypeIcon as type, type LucideIcon } from 'lucide-react'

interface ServiceGridProps {
  title: string
  services: {
    icon: LucideIcon
    label: string
    href: string
    badge?: "NEW" | "HOT"
  }[]
  className?: string
}

export function ServiceGrid({ title, services, className }: ServiceGridProps) {
  return (
    <div className={className}>
      <h2 className="mb-4 text-2xl font-semibold">{title}</h2>
      <div className="grid grid-cols-4 gap-4">
        {services.map((service) => (
          <a
            key={service.label}
            href={service.href}
            className="flex flex-col items-center"
          >
            <div className="relative mb-2 rounded-2xl bg-gray-100 p-4">
              {service.badge && (
                <span className={cn(
                  "absolute -right-1 -top-1 rounded-full px-2 py-0.5 text-[10px] text-white",
                  service.badge === "HOT" ? "bg-red-500" : "bg-green-500"
                )}>
                  {service.badge}
                </span>
              )}
              <service.icon className="h-6 w-6 text-gray-900" />
            </div>
            <span className="text-center text-xs text-gray-600">
              {service.label}
            </span>
          </a>
        ))}
      </div>
    </div>
  )
}

