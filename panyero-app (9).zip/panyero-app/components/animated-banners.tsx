'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { motion } from 'framer-motion'

const bannerUrls = [
  "https://firebasestorage.googleapis.com/v0/b/explore-malaysia-6d28d.appspot.com/o/Blue%20Modern%20Business%20Webinar%20banner_20241130_144109_0000.png?alt=media&token=0cf7a4d9-1163-43de-8ae8-e6ee2b732470",
  "https://firebasestorage.googleapis.com/v0/b/explore-malaysia-6d28d.appspot.com/o/Blue%20White%20Modern%20New%20Collection%20Banner_20241130_142811_0000.png?alt=media&token=ec462281-3296-4099-9243-b13fe2b554f4"
]

export function AnimatedBanners({ title }: { title: string }) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const truncatedTitle = title.slice(0, 8)

  return (
    <div className="flex flex-col items-center space-y-4 p-4">
      <h1 className="text-3xl font-bold mb-6">{truncatedTitle}</h1>
      {mounted && bannerUrls.map((url, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.2 }}
          className="w-full max-w-2xl"
        >
          <Image
            src={url}
            alt={`Banner ${index + 1}`}
            width={800}
            height={400}
            layout="responsive"
            className="rounded-lg shadow-lg"
          />
        </motion.div>
      ))}
    </div>
  )
}

