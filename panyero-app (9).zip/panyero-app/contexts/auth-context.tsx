import React, { createContext, useContext, useState, useEffect } from 'react'
import { auth, db } from '@/lib/firebase'
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut as firebaseSignOut, 
  onAuthStateChanged, 
  User 
} from 'firebase/auth'
import { setDoc, doc, getDoc } from 'firebase/firestore'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'

interface AuthContextType {
  user: User | null
  signUp: (email: string, password: string, mobileNumber: string, referralAccount: string) => Promise<void>
  signIn: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  getProfile: () => Promise<any>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const router = useRouter()

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user)
    })
    return () => unsubscribe()
  }, [])

  const signUp = async (email: string, password: string, mobileNumber: string, referralAccount: string) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)
      const user = userCredential.user

      await setDoc(doc(db, 'users', user.uid), {
        email,
        mobileNumber,
        referralAccount,
        createdAt: new Date(),
        isPhoneVerified: false,
      })

      toast.success('Account created successfully. Please verify your mobile number later.')
      router.push('/')
    } catch (error) {
      console.error("Error during sign up:", error)
      throw error
    }
  }

  const signIn = async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password)
      router.push('/')
    } catch (error) {
      console.error("Error during sign in:", error)
      throw error
    }
  }

  const signOut = async () => {
    try {
      await firebaseSignOut(auth)
      router.push('/auth/sign-in')
    } catch (error) {
      console.error("Error during sign out:", error)
      throw error
    }
  }

  const getProfile = async () => {
    if (!user) return null
    const docRef = doc(db, 'users', user.uid)
    const docSnap = await getDoc(docRef)
    return docSnap.exists() ? docSnap.data() : null
  }

  const value = {
    user,
    signUp,
    signIn,
    signOut,
    getProfile,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

