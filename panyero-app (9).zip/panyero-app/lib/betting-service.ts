const RAPIDAPI_KEY = '59ade3810amsh5866fb91182ed4fp11b245jsn9a0da3a16e46'
const RAPIDAPI_HOST = 'betfair-sports-casino-live-tv-result-odds.p.rapidapi.com'

export interface Game {
  id: string
  name: string
  type: string
  odds: number
  startTime: string
  status: string
  participants?: string[]
}

export interface Market {
  id: string
  name: string
  odds: number
  status: string
}

export async function fetchGames(): Promise<Game[]> {
  const options = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': RAPIDAPI_KEY,
      'X-RapidAPI-Host': RAPIDAPI_HOST
    }
  }

  try {
    const response = await fetch('https://betfair-sports-casino-live-tv-result-odds.p.rapidapi.com/api/getMarketDetails', options)
    
    if (!response.ok) {
      throw new Error('Failed to fetch games')
    }

    const data = await response.json()
    
    // Transform the API response to match our interface
    return data.events?.map((event: any) => ({
      id: event.id || String(Math.random()),
      name: event.name || 'Unknown Game',
      type: event.type || 'sport',
      odds: event.odds || 1.5,
      startTime: event.startTime || new Date().toISOString(),
      status: event.status || 'open',
      participants: event.participants || []
    })) || []
  } catch (error) {
    console.error('Error fetching games:', error)
    return []
  }
}

export async function getMarketOdds(marketId: string): Promise<Market[]> {
  const options = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': RAPIDAPI_KEY,
      'X-RapidAPI-Host': RAPIDAPI_HOST
    }
  }

  try {
    const response = await fetch(`https://betfair-sports-casino-live-tv-result-odds.p.rapidapi.com/api/getMarketOdds/${marketId}`, options)
    
    if (!response.ok) {
      throw new Error('Failed to fetch market odds')
    }

    const data = await response.json()
    return data.markets || []
  } catch (error) {
    console.error('Error fetching market odds:', error)
    return []
  }
}

